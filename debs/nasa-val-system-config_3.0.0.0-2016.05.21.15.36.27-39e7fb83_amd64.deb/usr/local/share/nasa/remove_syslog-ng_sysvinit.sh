#!/bin/bash

rm /etc/init.d/syslog-ng
