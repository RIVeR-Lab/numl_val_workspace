# ROS and Orocos
export ROS_DISTRO=indigo
source /opt/ros/indigo/setup.bash

if [ -f /opt/nasa/indigo/setup.bash ]; then
  source /opt/nasa/indigo/setup.bash
fi
