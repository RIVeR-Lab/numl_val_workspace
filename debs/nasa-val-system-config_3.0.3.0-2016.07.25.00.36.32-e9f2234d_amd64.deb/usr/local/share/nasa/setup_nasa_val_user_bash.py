#!/usr/bin/env python
import apt
import argparse
import os
from os.path import expanduser

HOME = expanduser("~")


def debian_is_installed(package):
    cache = apt.Cache()
    if cache[package].is_installed:
        return True

    return False


def message_to_user():
    print '''
Dear user, congrats, you have network-manager installed. This has to be the single worst bit of software ever created by man.
In order to make it play nice with /etc/network/interfaces you'll need to add the following to the bottom of
/etc/NetworkManager/NetworkManager.conf:

[keyfile]
unmanaged-devices=mac:XX:XX:XX:XX:XX:XX

NOTE: The mac address above is should be the interface you do NOT want NetworkManager to manage. You can add multiple interfaces.
'''


def main():
    """ main() function """
    parser = argparse.ArgumentParser(description='Sets up dotfiles in a users home directory. Do not run this script as root.')
    parser.add_argument('-s', '--src-path', dest='src_path', default=os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files'), help='Where to find the setup files. Default: /usr/local/share/nasa/files')
    parser.add_argument('-d', '--dst-path', dest='dst_path', default=HOME, help='Where to put the setup files. Default: ~/')
    args = parser.parse_args()

    if os.geteuid() == 0:
        print '>>> WARN: You should not run this as root. Please check the permissions on ~/.bash_nasa_val, ~/.bash_nasa_val.d, ~/.rttlua'

    print '>>> Please wait...'
    # Lets the vis users know they need to add an exception to Network Manager
    if debian_is_installed('network-manager'):
        message_to_user()

    print '>>> Attempting to move dotfiles...'

    if not os.system('cp -a {}/. {}/'.format(args.src_path, args.dst_path)) == 0:
        print 'There may have been errors. Exiting.'
    else:
        print '''
>>> Now add the following to your ~/.bashrc

if [ -f ~/.bash_nasa_val ]; then
  source ~/.bash_nasa_val
fi

>>> Finally, run:

source ~/.bashrc
'''

if __name__ == '__main__':
    main()
