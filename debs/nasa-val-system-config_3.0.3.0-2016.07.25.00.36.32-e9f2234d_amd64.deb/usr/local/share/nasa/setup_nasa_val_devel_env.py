#!/usr/bin/env python
"""Sets up users, groups, and installs debians to support Valkyrie development."""

import apt
import argparse
import errno
import grp
import os
import os.path
import pwd
import shutil
import stat
import sys
import yaml

DEFAULT_ROSDEP_SRC_PATH = os.path.join('etc', 'ros', 'rosdep', 'sources.list.d', '20-default.list')
ROSDEP_SRC_PATH = os.path.join('etc', 'ros', 'rosdep', 'sources.list.d')
OLD_ROSDEP_PATHS = [os.path.join(ROSDEP_SRC_PATH, '30-nasa-common.list'), os.path.join(ROSDEP_SRC_PATH, '31-nasa-trusty.list'), os.path.join(ROSDEP_SRC_PATH, '30-nasa-gazebo4.list'), os.path.join(ROSDEP_SRC_PATH, '12-nasa-gazebo4.list')]
BRAINSTEM = ['link01', 'link02', 'link03', 'link04', 'zelda01', 'zelda02', 'zelda03', 'zelda04']
VISUALIZER = ['vis01', 'vis02', 'vis03', 'vis04']
COMMON_DEB_KEYNAMES = ['common_base_debs', 'common_nasa_debs']
SYSLOGNG_INIT_PATH = os.path.join('etc', 'init.d', 'syslog-ng')
SYSTEM_GROUPS = ['ros', 'dialout', 'pgrimaging']


def delete_file_or_directory(target):
    """Deletes (with prejudice) a file or directory (recursively). Read-only files/directories are first set to writable, then deleted.

    @type target string
    @param target /path/to/dir or /path/to/file.ext

    @rtype bool
    @returns True if file/directory is deleted (or not there to begin with).
    """
    def make_writeable_and_try_again(func, path, exc_info):
        """Error callback for shutil.rmtree.

        Sets parent directory writable (if necessary) and the file itself writeable, then reexecutes the function that previously failed.
        """
        if func in (os.rmdir, os.remove) and exc_info[1].errno == errno.EACCES:
            # ensure parent directory is writeable too
            pardir = os.path.abspath(os.path.join(path, os.path.pardir))
            if not os.access(pardir, os.W_OK):
                os.chmod(pardir, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

            os.chmod(path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)  # 0777
            func(path)
        else:
            raise

    if os.path.exists(target):
        if os.path.isfile(target):
            os.remove(target)
        else:
            try:
                shutil.rmtree(target, ignore_errors=False, onerror=make_writeable_and_try_again)
            except OSError:
                return False

    return True


def debian_is_installed(package):
    """Check the system to see if the supplied deb is installed.

    NOTE: this cache is an instance of the existing system cache. If the system cache is modified this could be out of date.
    """
    cache = apt.Cache()
    if cache[package].is_installed:
        return True
    return False


def create_user(username, name=None):
    """Creates a user account.

    NOTE: This method does not support supplying a password.
    """
    if not name:
        name = username

    try:
        pwd.getpwnam(username)
    except KeyError:
        if os.system("useradd -s /bin/bash -d /home/{0} -m -c \"{1}\" {0}".format(username, name)) == 0:
            return True
        else:
            return False
    return True


def create_group(group):
    """Creates a group."""
    try:
        grp.getgrnam(group)
    except KeyError:
        if os.system("groupadd {}".format(group)) == 0:
            return True
        else:
            return False
    return True


def add_user_to_groups(group, username):
    """Adds a user to a group. If the user doesn't exist it will be created."""
    if not create_user(username):
        return False

    if not os.system("usermod -a -G {} {}".format(group, username)) == 0:
        return False
    return True


def create_users_and_groups(username):
    """Sets up the expected users and groups for our software."""
    if not create_user('vanguard'):
        print 'WARNING: User {} not created'.format('vanguard')

    for group in SYSTEM_GROUPS:
        if not create_group(group):
            print 'WARNING: Group {} not created'.format(group)

        if not add_user_to_groups(group, username):
            print 'WARNING: User: {}, not added to group: {}'.format(username, group)

    add_user_to_groups('sudo', 'vanguard')
    add_user_to_groups('ros', 'vanguard')


def load_yaml_file(path_to_file):
    """Load in the supplied yaml file and return the contents."""
    if os.path.isfile(path_to_file):
        with open(path_to_file) as file_object:
            try:
                yaml_object = yaml.load(file_object)
            except ValueError:
                print 'Could not parse the file {}'.format(path_to_file)
                return False

            return yaml_object

    return False


def create_install_list(args, deb_list):
    """Create list of common Debians to install."""
    install_list = []

    for name in COMMON_DEB_KEYNAMES:
        for value in deb_list[name]:
            install_list.append(value)

    return install_list


def install_debians(args, install_list):
    """Install all the selected Debians."""
    print '>>> Installing Debians. This will take some time, please wait...'

    if args.verbose:
        print '>>> List of Debians to install: {}\n'.format(install_list)

    if not os.system("apt-get -qq update") == 0:
        print '>>> WARN: apt-get update failed.'

    if not os.system("apt-get -qqy install {}".format(' '.join(install_list))) == 0:
        print '>>> WARN: apt-get install failed.'


def setup_developer(args, deb_list, install_list):
    """Setup the developer environment."""
    for key, value in deb_list['nasa_val_developer'].iteritems():
        if key == "developer":
            install_list.append(value)

    install_debians(args, install_list)


def setup_testbed(args, deb_list, install_list):
    """Setup the testbed environment."""
    for key, value in deb_list['nasa_val_developer'].iteritems():
        if key == "developer":
            install_list.append(value)

    for key, value in deb_list['nasa_val_robot_support'].iteritems():
        if key == "testbed":
            for deb in value:
                install_list.append(deb)

    install_debians(args, install_list)


def setup_robot(args, deb_list, install_list):
    """Setup the robot environment."""
    for key, value in deb_list['nasa_val_robot'].iteritems():
        if key == args.brainstem_type:
            install_list.append(value)

    for key, value in deb_list['nasa_val_robot_support'].iteritems():
        if key in args.brainstem_type:
            for deb in value:
                install_list.append(deb)

    install_debians(args, install_list)


def setup_visualizer(args, deb_list, install_list):
    """Setup the visualizer environment."""
    for key, value in deb_list['nasa_val_visualizer'].iteritems():
        if key == args.visualizer_type:
            install_list.append(value)

    install_debians(args, install_list)


def setup_rosdep_urls(args, rosdep_url_list):
    """Add the supplied URLs to the rosdep list."""
    # Rosdep debian installed?
    if not debian_is_installed('python-rosdep'):
        return False

    # Remove old keys
    for file_path in OLD_ROSDEP_PATHS:
        if os.path.isfile(file_path):
            delete_file_or_directory(file_path)

    # Check if rosdep was setup before
    if os.path.isfile(DEFAULT_ROSDEP_SRC_PATH):
        delete_file_or_directory(DEFAULT_ROSDEP_SRC_PATH)

    # Init rosdep
    os.system("rosdep init -q")

    # Public or private?
    url_type = 'public'
    if args.private:
        url_type = 'private'

    # Add nasa rosdep urls
    for key, value in rosdep_url_list[url_type].iteritems():
        with open(value['location'], "wb+") as file_object:
            file_object.write("yaml {}\n".format(value['url']))

    return True


def main():
    """The main function."""
    parser = argparse.ArgumentParser(description='Installs the required packages for the selected Valkyrie robot or developer environment. Root or sudo required to run this script.')

    paths = argparse.ArgumentParser(add_help=False)
    paths.add_argument('--deb-list', dest='deb_list', default=os.path.join(os.path.dirname(os.path.realpath(__file__)), 'configs', 'nasa_val_dev_env_debs.yaml'), help='Fully qualified path to yaml file containing debs to install. Default: ./configs/nasa_val_dev_env_debs.yaml')
    paths.add_argument('--rosdep-url-list', dest='rosdep_url_list', default=os.path.join(os.path.dirname(os.path.realpath(__file__)), 'configs', 'nasa_rosdep_urls.yaml'), help='Fully qualified path to yaml file containing rosdep key URLS. Default: ./configs/nasa_rosdep_urls.yaml')
    paths.add_argument('--private', action='store_true', default=False, help='Choose private nasa URL settings. Default: false')
    paths.add_argument('-u', '--username', dest='username', default=pwd.getpwuid(os.getuid())[0], help='User to add to groups. Default: current user')
    paths.add_argument('--verbose', action='store_true', help='Print out extra debug messages to the terminal')

    sp = parser.add_subparsers()
    sp_developer = sp.add_parser('developer', parents=[paths], help='Select the \'developer\' option to setup a general purpose machine')
    sp_testbed = sp.add_parser('testbed', parents=[paths], help='Select the \'testbed\' option to setup a testbed bench')
    sp_robot = sp.add_parser('robot', parents=[paths], help='Select the \'robot\' option to setup up a robot processor. WARN: This will change networking and apt settings')
    sp_visualizer = sp.add_parser('visualizer', parents=[paths], help='Select the \'visualizer\' option to setup up a visualizer computer. WARN: This will change networking and apt settings')

    sp_developer.set_defaults(func=setup_developer)
    sp_testbed.set_defaults(func=setup_testbed)
    sp_robot.set_defaults(func=setup_robot)
    sp_visualizer.set_defaults(func=setup_visualizer)

    sp_robot.add_argument('--brainstem-type', dest='brainstem_type', choices=BRAINSTEM, required=True, help='Select the brainstem computer to install from the above choices')
    sp_visualizer.add_argument('--visualizer-type', dest='visualizer_type', choices=VISUALIZER, required=True, help='Select the visualizer computer to install from the above choices')

    args = parser.parse_args()

    # Root check
    if os.geteuid() != 0:
        print ">>> Script must be run as root"
        sys.exit(1)

    # Setup basic users and groups
    create_users_and_groups(args.username)

    # Load yaml files
    deb_list = load_yaml_file(args.deb_list)
    rosdep_url_list = load_yaml_file(args.rosdep_url_list)

    # Install debian packages specific to the machine type specified
    if deb_list:
        install_list = create_install_list(args, deb_list)

        args.func(args, deb_list, install_list)

    else:
        print '>>> ERROR: Unable to load supplied files for Debians to install'
        sys.exit(1)

    # Setup Rosdep
    if rosdep_url_list:
        if not setup_rosdep_urls(args, rosdep_url_list):
            print '>>> ERROR: rosdep init failed. Is python-rosdep installed?'
    else:
        print '>>> ERROR: Unable to load supplied files for rosdep URLs to add. Skipping rosdep init step.'

    # Final Steps - remove syslog-ng init file because we have a custom one
    if os.path.isfile(SYSLOGNG_INIT_PATH):
        delete_file_or_directory(SYSLOGNG_INIT_PATH)

    print """
\n>>> Setup complete. Please run:

rosdep update

>>> Finally, to setup your user account, please run:

python /usr/local/share/nasa/setup_nasa_val_user_bash.py
"""

if __name__ == '__main__':
    main()
