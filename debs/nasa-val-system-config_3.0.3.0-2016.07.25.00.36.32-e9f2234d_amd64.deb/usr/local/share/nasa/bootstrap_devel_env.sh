#!/bin/bash
# Look there is nothing fancy about this script
# It sets up some exta sources and installs our
# most basic package so that users have access
# to the rest of the scripts needed to set up
# your development environment

# Make sure only root can run our script
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

check_if_continue ()
{
    if [ $1 -ne 0 ]; then
        echo -e "\nFAILED: $2\n"
        exit 1
    fi
}

echo ""
echo "Installing sources, please wait..."
echo ""

apt-get -qq update
check_if_continue $? $"apt-get update. Do you have internet connection?"

apt-get -qqy install wget
check_if_continue $? $"apt-get install wget. Do you have internet connection?"

sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'
apt-key adv --keyserver hkp://pool.sks-keyservers.net --recv-key 0xB01FA116
check_if_continue $? $"adding ros-latest key via apt-key. Do you have internet connection?"
 
sh -c 'echo "deb http://packages.osrfoundation.org/gazebo/ubuntu `lsb_release -cs` main" > /etc/apt/sources.list.d/gazebo-latest.list'
wget -O - http://packages.osrfoundation.org/gazebo.key | apt-key add -
check_if_continue $? $"adding gazebo-latest key via wget. Do you have internet connection?"
 
sh -c 'echo "deb http://flexo.jsc.nasa.gov/repos/apt/trusty stable thirdparty" > /etc/apt/sources.list.d/nasa_trusty_thirdparty.list'
sh -c 'echo "deb http://flexo.jsc.nasa.gov/repos/apt/trusty testing main" > /etc/apt/sources.list.d/nasa_trusty.list'
wget -O - http://flexo.jsc.nasa.gov/repos/apt/trusty/flexo.gpg.key | apt-key add -
check_if_continue $? $"adding nasa_trusty/nasa_trusty_thirdparty keys via wget. Do you have internet connection? Can you resolve flexo.jsc.nasa.gov?"

echo ""
echo "Please wait... "

apt-get -qq update
check_if_continue $? $"apt-get update. Do you have internet connection?"

apt-get -qqy upgrade
check_if_continue $? $"apt-get upgrade. Do you have internet connection?"

apt-get -qqy install git nasa-indigo-workspace nasa-val-system-config python-pip python-rosdep python-vcstool ros-indigo-catkin syslog-ng-core
check_if_continue $? $"apt-get install git nasa-indigo-workspace nasa-val-system-config python-pip python-rosdep python-vcstool ros-indigo-catkin syslog-ng-core. Do you have internet connection?"

echo ""
echo "To continue your setup, please run:"
echo ""
echo "python /usr/local/share/nasa/setup_nasa_val_devel_env.py"
echo ""
